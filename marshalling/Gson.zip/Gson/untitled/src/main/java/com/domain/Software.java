package com.domain;

public class Software {
}
